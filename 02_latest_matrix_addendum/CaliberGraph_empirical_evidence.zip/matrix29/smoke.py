"""Runtime/resource fixture only, no selected natural SQL."""
import sys,subprocess,time,json
from common import P,PILOT,PARSEVAL,dump
from owned_processes import OwnedCase,Stopped
mode=sys.argv[1]
if mode=='parseval':
    sys.path[:0]=[str(PARSEVAL/'dependencies_local/site-packages'),str(PARSEVAL/'sources_local/parseval_official/src')]
    import parseval,z3,sqlglot,sqlalchemy,sqlite3
    z3.set_param('memory_max_size',512);s=z3.Solver();s.set(timeout=3000,max_memory=512);s.add(z3.BoolVal(False));ans=str(s.check());assert ans=='unsat'
    print(json.dumps({'path':mode,'imported':True,'z3':z3.get_version_string(),'sqlglot':sqlglot.__version__,'sqlite':sqlite3.sqlite_version,'synthetic_solver_checks':1,'result':ans,'natural_cases':0}))
elif mode=='polygon':
    sys.path[:0]=[str(PILOT/'runtime_local'),str(PILOT/'dependencies_local')]
    import polygon.environment
    with OwnedCase(3) as g:
        p=g.spawn([str(PILOT/'native_local/z3'),'-version','-memory:512'],stdout=subprocess.PIPE,stderr=subprocess.PIPE);v,e=p.communicate(timeout=2);assert p.returncode==0
    print(json.dumps({'path':mode,'imported':True,'native_version':v.decode().strip(),'guard_all_reaped':g.receipt()['all_reaped'],'natural_cases':0}))
elif mode=='cleanup':
    g=OwnedCase(.15)
    try:
        with g:
            g.spawn(['/opt/homebrew/bin/python3.12','-S','-B','-c','import time;time.sleep(3)']);time.sleep(1)
    except Stopped:pass
    r=g.receipt();assert r['all_reaped'] and r['reason']=='CASE_DEADLINE';print(json.dumps({'path':mode,'all_reaped':r['all_reaped'],'stop':r['reason'],'natural_cases':0}))
