# Independent pre-review — Matrix 29

**PASS_PROTOCOL_PENDING_CODE**. This is an explicitly authorized development audit, not a held-out evaluation or v1 promotion. Unsupported, timeout, failure, and all-negative outcomes are valid results; they must remain in the fixed 33-case denominators.

Independent recomputation agrees with all 1,534 inventory rows, all SHA256 ranks and lexical strata, and the ordered selection of 33 cases (11 schemas × one VALUE, AGG_BAG, OTHER each). Both corpus hashes match. All 99 selected input files match source bytes and declared hashes, and all 33 record commitments match. The reviewer did not import or execute author preparation code, natural SQL, or SMT.

The preregistered budget is one worker, 3 seconds per solver call, 10 seconds per system-case end-to-end, 1,200 seconds for the natural batch, no retries, one OMP thread, and Z3 internal 512 MiB. The Python 1 GiB self-RSS soft stop is not an aggregate RSS hard cap. Code enforcement and process cleanup remain to be reviewed.

ParSEval's expandable native row generation and Polygon N≤1 do not establish a common search domain. Equal time caps support descriptive costs only; speed winners or solve-rate comparisons require independently established common query, type, constraint, row, and comparison domains. Native EQ/EQU meanings must remain qualified and cannot establish universal SQLite correctness. Shared Z3 and possible shared concepts preclude an independent-two-oracle claim.

Final execution sign-off is pending the frozen controller/worker/replay source, raw and overlay fingerprints, and minimal synthetic/import/resource smoke evidence. Check the JSON for the exact pending items and reviewed hashes. No automatic promotion gate is used to veto this user-authorized development audit.
