"""Independent saved-witness audit; standard library only, no solver imports."""
from pathlib import Path
import collections, hashlib, json, re, signal, sqlite3, time

BASE = Path(__file__).resolve().parents[1]
START = time.monotonic()
END = START + 120

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def ident(name):
    return '"' + name.replace('"', '""') + '"'

def top_order(sql):
    # Quotes/comments are tokens and never interpreted as ORDER BY clauses.
    tokens = re.findall(r"--[^\n]*|/\*.*?\*/|'(?:[^']|'')*'|\"(?:[^\"]|\"\")*\"|`[^`]*`|\[[^\]]*\]|\w+|[^\s]", sql, re.S)
    depth = 0
    previous = None
    for token in tokens:
        if token.startswith(('--', '/*')):
            continue
        if token == '(':
            depth += 1
        elif token == ')':
            depth -= 1
        elif depth == 0 and token.upper() == 'BY' and previous == 'ORDER':
            return True
        previous = token.upper() if depth == 0 else None
    return False

def alarm(*args):
    raise TimeoutError('independent replay deadline')

signal.signal(signal.SIGALRM, alarm)
results = []
for path in sorted((BASE / 'run_01').glob('*/candidate_*.json')):
    if time.monotonic() >= END:
        raise TimeoutError('whole independent replay budget exhausted')
    before = time.monotonic()
    deadline = min(before + 2, END)
    signal.setitimer(signal.ITIMER_REAL, deadline - before)
    cid, system = path.parent.name.rsplit('__', 1)
    source = BASE / 'inputs' / cid
    rec = {'candidate': str(path.relative_to(BASE)), 'case_id': cid, 'system': system,
           'candidate_sha256': sha(path), 'full_C_valid': False, 'different': False,
           'query_errors': [], 'outputs': []}
    db = None
    try:
        saved = json.loads(path.read_text())
        queries = [(source / name).read_text() for name in ('gold.sql', 'predicted.sql')]
        rec['ordered'] = all(top_order(q) for q in queries)
        db = sqlite3.connect(':memory:')
        db.set_progress_handler(lambda: int(time.monotonic() >= deadline), 500)
        db.execute('PRAGMA foreign_keys=ON')
        assert db.execute('PRAGMA foreign_keys').fetchone()[0] == 1
        db.executescript((source / 'full-schema.sql').read_text())
        tables = {row[0].casefold(): row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
        assert len(saved) == len(tables) and {n.casefold() for n in saved} == set(tables), 'table coverage'
        db.execute('BEGIN')
        db.execute('PRAGMA defer_foreign_keys=ON')
        rec['rows_per_table'] = {}
        for key, payload in saved.items():
            name = tables[key.casefold()]
            cols = {row[1].casefold(): row[1] for row in db.execute('PRAGMA table_info(' + ident(name) + ')')}
            names = payload['columns']
            assert len(names) == len(cols) and {n.casefold() for n in names} == set(cols), 'column coverage'
            names = [cols[n.casefold()] for n in names]
            rec['rows_per_table'][name] = len(payload['rows'])
            statement = 'INSERT INTO ' + ident(name) + '(' + ','.join(map(ident, names)) + ') VALUES (' + ','.join('?' for _ in names) + ')'
            for row in payload['rows']:
                assert len(row) == len(names), 'row width'
                assert all(type(x) in (int, float, str, bool, type(None)) for x in row), 'value representation'
                db.execute(statement, row)
        rec['foreign_key_check'] = db.execute('PRAGMA foreign_key_check').fetchall()
        rec['integrity_check'] = db.execute('PRAGMA integrity_check').fetchall()
        assert rec['foreign_key_check'] == [] and rec['integrity_check'] == [('ok',)], 'constraint checks'
        db.commit()
        rec['full_C_valid'] = True
        db.execute('PRAGMA query_only=ON')
        for query in queries:
            try:
                rec['outputs'].append(db.execute(query).fetchall())
                rec['query_errors'].append(None)
            except sqlite3.Error as error:
                rec['outputs'].append(None)
                rec['query_errors'].append(str(error))
        rec['asymmetric_query_error'] = bool(rec['query_errors'][0]) != bool(rec['query_errors'][1])
        if not any(rec['query_errors']):
            a, b = rec['outputs']
            rec['different'] = a != b if rec['ordered'] else collections.Counter(a) != collections.Counter(b)
    except Exception as error:
        rec['replay_error'] = type(error).__name__ + ': ' + str(error)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        if db is not None:
            db.close()
    rec['elapsed_s'] = time.monotonic() - before
    results.append(rec)

report = {'implementation': 'independent standard-library sqlite3; no author replay imported',
          'sqlite_version': sqlite3.sqlite_version, 'single_worker': True, 'per_candidate_seconds': 2,
          'batch_limit_seconds': 120, 'elapsed_s': time.monotonic() - START,
          'new_solver_calls': 0, 'candidates': len(results), 'results': results}
(BASE / 'review/INDEPENDENT_REPLAY.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'results'}))
