# Matrix 29 非作者最终审核

**ACCEPT_WITH_LIMITATIONS**（实证记录审计通过）。固定 33 对 × 2 系统共 66 槽完整保留，无重复、无删除 unsupported 或阴性结果。832 个冻结文件、两个源文件哈希及 99 个原始输入字节重新核对通过；MATRIX.json、CSV 与 SUMMARY 的分类、分层、候选数和描述性成本全部独立重算一致。

独立标准库 SQLite 3.53.3 回放全部 116 个保存候选，未导入作者 replay，未调用 solver，单 worker，总计 0.176 秒（每候选上限 2 秒、总上限 120 秒）。116 个均满足原始完整 DDL 约束；ParSEval 18 个区分、96 个不区分，Polygon 1 个区分、1 个不区分。所有输出、排序/多重集判据、错误与作者记录一致。

ParSEval：18 有效 NEQ、8 采样一致、3 原 SQL 无效、1 UNKNOWN、3 超时。Polygon：25 既有 schema 映射缺失、3 原 SQL 无效、2 查询语义门拒绝、1 有效 NEQ、1 有界 UNSAT、1 完整约束有效但不区分的见证。分母各为 33。

批次耗时 54.687 秒；73 个 owned handles 全部收回，无 cleanup errors。worker 退出码为 30 个 0 和 36 个 -15：其中 33 个 -15 已保存完整 terminal RESULT/guard/CPU/RSS，3 个仍为 STARTED 并正确记为超时。不能表述为“66 个进程正常退出”。三例含清理耗时分别约 10.017、10.008、10.011 秒；512 MiB 是 Z3 内部限制，非聚合 RSS 硬限。

`toxicology__223` 的两个 SELECT 分别输出 1 列、2 列，保存见证在原 SQLite 返回 `[]` 与 `[]`。本轮冻结的 row-bag 判据下不区分。runtime `environment.py:517` 与上游 `:519` 的异 arity equality 分支均返回 `Or(size1>0,size2>0)`，调用处又取 Not；保存 `formula_1.smt2:8` 正是其否定，`:9` 的 under 固定两个输出 choice=0。因此这里有源码及保存公式支持的局部方向问题，解释了为什么两边空仍产生 native NEQ。该诊断不得升级为全工具错误率、新科学机制或性能胜负。

两路径共享 Z3；行数界、语义覆盖和比较合同尚无共同域认证。8 次采样一致及 1 次有界 UNSAT 均不是 SQLite 普遍等价证明。本批为既有语料开发审计，不是新 held-out test。已审核作者 RESULT.zh.md：分类、分母、资源披露、适配覆盖边界和单例诊断措辞可接受；未将 18/33 与 1/33 用于排名。报告 SHA256 为 `f86bbe9b4c053329f42534c27329ada4cde203a5f3e344c27a9654c1ce9f2e8d`。P19 新颖性与投稿成熟度属于作者判断，不在此次窄范围独立审计的验证范围内。
