# CaliberGraph 29：跨 schema 小型开发审计实跑

**裁决：这一轮补齐了实际执行与完整失败分母，但仍为 HOLD_EMPIRICAL_PAPER；不支持新方法成立、系统胜负或独立实证稿已具备充分证据。** 33 对查询来自既有 BIRD 1,534 对/11 schema，每个 schema 按冻结哈希抽取 VALUE、AGG_BAG、OTHER 各一对。类别是词法代理；未按执行成败选择或替换。整个语料此前已静态暴露，本轮全部是开发审计，未触碰或宣称新的最终测试集。

非作者审查先核全部 1,534 条的排序/类别、99 个输入文件及 33 条源记录哈希，再审核执行代码与 832 个冻结文件，签署 `review/EXECUTION_GATE.json` 后才启动。原始 SQL、完整源 DDL、约束清单及实际代码版本均保留。`MATRIX.csv` 为 66 槽明细，`SUMMARY.json` 为按 schema/类别统计，原始证据位于 `run_01/`。

## 实际结果

|最终处置（各系统分母均为33）|ParSEval 资源适配路径|Polygon pilot13 UA 资源适配路径|
|---|---:|---:|
|原 SQLite/full C 有效且行结果不同的见证|18|1|
|仅已生成样本一致，不是等价证明|8|0|
|仅编码片段内有界 UNSAT，不是 SQLite 无界 EQ|0|1|
|原始 SQL 无效|3|3|
|既有完整 schema 映射缺失|0|25|
|保守查询语义门拒绝|0|2|
|原生 UNKNOWN/编译不支持原因|1|0|
|10 秒系统×查询截止|3|0|
|full C 有效但未区分行结果的候选|0|1|
|合计|33|33|

ParSEval 的 18 个有效见证分布于全部 11 个 schema；本轮保存的 114 个候选数据库均通过原 DDL 约束回放，其中 18 个实际区分原查询。Polygon 保存 2 个候选，二者均符合源约束，1 个区分行结果。没有候选违反源 full C，也没有非对称查询执行错误。这里的 full C 指原始 DDL 声明的约束，不包含未提供的业务规则。候选数据库数量不是独立样本数量；不同系统的同一查询也不能重复计算为独立查询。

三个无效输入是预测 SQL 的缺列/歧义错误：`codebase_community__677` 的 `T1.CreationDate`、`debit_card_specializing__1479` 的 `Currency`、`toxicology__335` 的 `molecule_id`。未修复或替换。ParSEval `financial__169` 返回 UNKNOWN，原因是 `q2: A sum does not bind its row variable`，不能合并成 solver timeout。`formula_1__981`、`student_club__1381`、`superhero__834` 是端到端截止；已保存候选和调用记录均保留，最终仍记超时。

Polygon 的 25 个缺映射结果仅说明本轮既有适配路径的覆盖边界，**不能声称原生 Polygon 不支持这 25 对 SQL**。只复用已审核的 superhero/toxicology 映射，没有新增语义映射，也未装载后续 COUNT 修复版本。两系统均使用 Z3 4.16.0，审计也共享 SQLite 与数据源；不称为两个完全独立实现或两个独立真值 oracle。

## 单个未区分候选与可证伪解释

`toxicology__223` 的 gold 选择一列、predicted 选择两列，且比较的字符串常量不同。Polygon 返回 NEQ 的具体数据库符合全部源约束，但原 SQLite 查询均返回空行集。按照本轮预登记的“成功执行后的行 bag/list”判据，它不是区分见证；不能把输出列数不同这一事实悄悄加入主统计判据。

仅检查冻结源码与保存的 SMT，发现 `polygon/environment.py` 的同列数分支返回等价条件，异列数分支却返回“至少一边非空”；调用方再取反。本次 `formula_1.smt2` 的 `neq` 明确为“两边均空”，与该具体候选相符。这是可定位的比较契约/编码方向问题线索，须结合上游代码和非作者审核限定归因；本轮不修复、不重跑，也不把单例当跨 schema 规律、新方法或新的论文贡献。尚未核其是否已有公开 issue。

## 资源和执行证据

自然批次仅执行一次，66/66 槽，54.687 秒；单 worker，无重试。记录到 ParSEval 355 次 Python Z3 check、Polygon 7 次 native Z3 check，均有返回记录；最长记录的 check 为 0.629 秒。预设每次 check 3 秒、每槽端到端 10 秒、整批 1,200 秒、每 Z3 内部内存 512 MiB。三个截止槽含清理尾部为 10.008–10.017 秒。所有 73 个自有 Popen handle（66 worker、7 native Z3）均回收，cleanup_errors 为空。

控制器在 worker 关闭通信 socket 后立即清理，因此 36 个 worker 返回码为 -15、30 个为 0；不把它们全部称为正常退出。非超时结果依据已写出的终态 RESULT 和保存数据库，而三个超时仅有 STARTED 检查点。每系统成本仅作描述，不作速度胜负：ParSEval 总槽时间 51.916 秒，Polygon 2.729 秒（多数止于准入门）。ParSEval 已记录 worker 自身峰值约 108.8 MiB，Polygon 48.6 MiB；缺少终态的超时 worker 不计入该峰值，因此它不是所有槽的全局上界，也不含子进程。

启动前 load average 为 3.04/2.77/2.76，读取了 vm_stat。`hw.memsize` 读取被系统拒绝后未重试；没有更改权限。资源契约是内部 Z3 限制与自身 RSS 软停止，**不是整批 RSS 硬上限**。未启动 GPU、大队列或改动 unrelated_project；没有测量 unrelated_project 吞吐，因此不保证其吞吐完全不变。批后一次只读源码命令遇到 exec-server transport disconnected，恢复连接后继续只读检查，未再次启动自然实验。

## 对实证稿的影响

本轮证明：在固定完整分母下，现成路径能够产生跨 schema 的可回放见证；输入错误、适配覆盖、生成限制、时限以及见证与比较契约之间的差异需要分别计数。它补上了上一裁决缺少的“小规模真实端到端矩阵”，但 Polygon 仅三对有效输入进入求解；两系统行数界、语义域及成本结构未匹配，无法估计公平相对可靠性。18/33 与 1/33 不能用来排名。

独立实证论文仍缺少跨工具共同域中的可迁移规律、相邻先例/已有缺陷去重，以及独立验证组。比较契约、checker、哈希和拒绝机制本身已与 P19 重叠；新增日志不是新科学发现。当前只支持保存开发审计证据，不能据此改写投稿。结果不要求胜过 baseline，也没有以“缺少新算法”作为唯一否决理由。本轮未改原稿、P19 或旧冻结实验。

非作者最终复核另见 `review/FINAL_REVIEW.zh.md`；审核使用独立编写的 SQLite 回放实现，不启动新的 solver。
