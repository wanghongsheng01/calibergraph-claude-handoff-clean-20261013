"""Single cold system/case worker, existing engines; no new semantic translator."""
from pathlib import Path
import array,json,os,resource,socket,sys,time,traceback
from common import P,ROOT,PILOT,PARSEVAL,inputs,dump,replay,admission
from owned_processes import OwnedCase,Stopped
system,cid,fd,outpath=sys.argv[1:];out=Path(outpath);started=time.monotonic();sock=socket.socket(fileno=int(fd))
R={'system':system,'case_id':cid,'status':'STARTED','solver_calls':[],'candidates':[],'versions':{},'development_only':True};proxies=[]
def checkpoint():R['elapsed_s']=time.monotonic()-started;dump(out/'RESULT.json',R)
def run_parseval(queries,ddl):
    sys.path[:0]=[str(PARSEVAL/'dependencies_local/site-packages'),str(PARSEVAL/'sources_local/parseval_official/src')]
    import importlib,sqlite3,sqlglot,z3,sqlalchemy
    z3.set_param('memory_max_size',512);z3.set_param('parallel.enable',False)
    from parseval.generator import GenerationConfig
    from parseval.db_manager import Connect
    pm=importlib.import_module('parseval.main')
    R['versions']={'sqlite':sqlite3.sqlite_version,'sqlglot':sqlglot.__version__,'z3':z3.get_version_string(),'sqlalchemy':sqlalchemy.__version__}
    R['ordered']=all(t and t.args.get('order') for t in [sqlglot.parse_one(q,read='sqlite') for q in queries])
    R['ordered']=bool(R['ordered']);original_check=z3.Solver.check
    def check(self,*args,**kwargs):
        self.set(timeout=3000,max_memory=512);c={'index':len(R['solver_calls']),'status':'STARTED','timeout_ms':3000,'max_memory_MiB':512};R['solver_calls'].append(c);checkpoint();t=time.monotonic()
        try:
            ans=original_check(self,*args,**kwargs);c['status']=str(ans)
            if str(ans)=='unknown':c['reason']=self.reason_unknown()
            return ans
        finally:c['elapsed_s']=time.monotonic()-t;checkpoint()
    z3.Solver.check=check
    orig_load=Connect.load
    def load(self,instance):
        i=len(R['candidates']);row={'index':i,'state':'LOAD_STARTED'};R['candidates'].append(row);checkpoint()
        try:
            ans=orig_load(self,instance)
            data={n:{'columns':rs[0],'rows':rs[1:]} for n,rs in self.get_all_table_rows().items()}
            path=out/f'candidate_{i:03}.json';dump(path,data);row['database_file']=path.name;row['state']='LOADED_SNAPSHOT'
            # An observer, no changed generator arguments or feedback.
            row['independent_original_SQLite_replay']=replay(cid,data,R['ordered']);checkpoint();return ans
        except BaseException as e:row['load_or_observer_error']=repr(e);checkpoint();raise
    Connect.load=load
    config=GenerationConfig(timeout_ms=3000,time_limit_s=10,min_string_length=1,speculate=True,seed=0,set_semantics=False)
    R['phase']='NATIVE_DISPROVE';checkpoint()
    answer=pm.disprove(*queries,ddl,'sqlite:///:memory:','sqlite',config=config,timeout_s=3,set_semantics=False)
    R['native_verdict']=answer.verdict.value;R['native_reason']=answer.reason;R['native_results']=answer.results
    if answer.verdict.value=='EQ':R['status']='SAMPLED_AGREEMENT_NOT_PROOF'
    elif answer.verdict.value=='NEQ':
        last=R['candidates'][-1].get('independent_original_SQLite_replay',{})
        R['status']='VALIDATED_NEQ' if last.get('full_C_valid') and last.get('different') else 'ASYMMETRIC_QUERY_ERROR' if last.get('full_C_valid') and last.get('asymmetric_query_error') else 'INVALID_OR_NON_DISTINGUISHING_WITNESS'
    elif answer.verdict.value=='UNKNOWN':R['status']='UNSUPPORTED_OR_UNKNOWN';
    else:R['status']='NATIVE_'+answer.verdict.value
def run_polygon(queries,a):
    if not a['polygon_mapping']:R['status']='UNSUPPORTED_SCHEMA_MAPPING';return
    sys.path[:0]=[str(PARSEVAL/'dependencies_local/site-packages')]
    import sqlglot
    trees=[sqlglot.parse_one(q,read='sqlite') for q in queries]
    # Keep already-certified source schema, refuse known unsupported dialect obligations.
    forbidden={'Cast','TryCast','Div','Date','DateDiff','TimeToStr','StrToTime','Substring','Round','Case','If','Coalesce','Nullif','RegexpLike','Like','ILike','Concat','Anonymous','Window','Union','Intersect','Except'}
    reasons=sorted({type(n).__name__ for t in trees for n in t.walk() if type(n).__name__ in forbidden})
    if reasons:R.update(status='UNSUPPORTED_QUERY_SEMANTICS',query_gate_reasons=reasons);return
    R['ordered']=bool(all(t.args.get('order') for t in trees));R['query_gate']='No completeness certificate; concrete output is validated; UNSAT scoped only to encoded typed fragment'
    sys.path[:0]=[str(PILOT/'runtime_local'),str(PILOT/'dependencies_local')]
    import polygon.environment as environment
    import polygon.smt.provers.smtlibv2 as smt
    class Reader:
        def __init__(self,stream):self.stream=stream
        def readline(self,*args):
            line=self.stream.readline(*args)
            if not line or line.strip() in ('unknown','timeout'):raise RuntimeError('Z3_PROTOCOL_'+(line.strip() or 'EOF'))
            return line
        def close(self):self.stream.close()
    def broker_popen(argv,**kwargs):
        sock.send(json.dumps({'op':'spawn_z3','argv':argv}).encode());data,anc,flags,addr=sock.recvmsg(4096,socket.CMSG_SPACE(2*array.array('i').itemsize));reply=json.loads(data);fds=array.array('i')
        for lev,typ,payload in anc:
            if lev==socket.SOL_SOCKET and typ==socket.SCM_RIGHTS:fds.frombytes(payload)
        if not reply.get('ok') or len(fds)!=2:raise RuntimeError('broker refused')
        obj=type('RemotePipes',(),{})();obj.stdin=os.fdopen(fds[0],'w',buffering=1);obj.stdout=Reader(os.fdopen(fds[1],'r'));proxies.append(obj);return obj
    smt.Popen=broker_popen;orig_check=smt.SMTLIBv2.check
    def check(prover,formula):
        i=len(R['solver_calls']);c={'index':i,'status':'STARTED'};R['solver_calls'].append(c);(out/f'formula_{i}.smt2').write_text(formula);checkpoint();t=time.monotonic()
        try:ans=orig_check(prover,formula);c['status']='SAT' if ans else 'UNSAT';return ans
        except BaseException as e:c['status']='ERROR';c['error']=repr(e);raise
        finally:c['elapsed_s']=time.monotonic()-t;checkpoint()
    smt.SMTLIBv2.check=check
    inv=json.loads(Path(a['polygon_mapping']).read_text());schema=[{'TableName':t['table'],'PKeys':[],'FKeys':[],'Others':[{'Name':c['name'],'Type':{'INTEGER':'int','TEXT':'varchar'}[c['source_type']]} for c in t['columns']]} for t in inv['tables']]
    R['bound_per_source_table']=1;R['phase']='POLYGON_UA';checkpoint()
    env=environment.Environment(schema,inv['proposed_polygon_constraint_entries'],bound=1,time_budget=3)
    raw=env.check(*queries,use_precise_encoding=False,solver_timeout_seconds=3);R['native_return']=raw
    status=raw[4].get('status');R['status']='BOUNDED_SYMBOLIC_UNSAT_NOT_SQLITE_EQ' if status=='EQU' else 'NATIVE_'+str(status)
    if status=='NEQ':
        data={n:{'columns':rs[0],'rows':rs[1:]} for n,rs in raw[1].items()};dump(out/'candidate_000.json',data)
        checked=replay(cid,data,R['ordered']);R['candidates']=[{'index':0,'database_file':'candidate_000.json','independent_original_SQLite_replay':checked}]
        R['status']='VALIDATED_NEQ' if checked.get('full_C_valid') and checked.get('different') else 'INVALID_OR_NON_DISTINGUISHING_WITNESS'
try:
    resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_CPU,(12,12))
    with OwnedCase(10,interval=.05) as guard:
        _,ddl,queries=inputs(cid);R['phase']='ORIGINAL_DDL_EXPLAIN';checkpoint();a=admission(cid);R['admission']=a;checkpoint()
        if not a['valid_input']:R['status']='INVALID_ORIGINAL_SQL'
        elif system=='parseval':run_parseval(queries,ddl)
        elif system=='polygon':run_polygon(queries,a)
        else:raise ValueError(system)
except Stopped as e:R.update(status='TIMEOUT_OR_RESOURCE_STOP',error=str(e))
except (PermissionError,) as e:R.update(status='PERMISSION_DENIED_PATH',error=repr(e))
except NotImplementedError as e:R.update(status='UNSUPPORTED_NATIVE',error=repr(e))
except BaseException as e:R.update(status='ERROR',error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc())
finally:
    for obj in proxies:
        for s in [obj.stdin,obj.stdout]:
            try:s.close()
            except Exception:pass
    if 'guard' in locals():R['guard']=guard.receipt()
    R['own_peak_rss_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    R['own_cpu_s']=resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime
    checkpoint();sock.close()
