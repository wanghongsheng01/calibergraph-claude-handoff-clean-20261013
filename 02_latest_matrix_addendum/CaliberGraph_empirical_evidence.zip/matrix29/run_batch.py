"""One serial launch; own Popen handles, per-slot and whole-batch deadlines."""
import array,fcntl,json,os,select,socket,subprocess,time
from pathlib import Path
from common import P,ROOT,PILOT,sha,dump
from owned_processes import OwnedCase,Stopped
PY='/opt/homebrew/bin/python3.12'
def main():
    freeze=json.loads((P/'FREEZE.json').read_text())
    for name,digest in freeze['files'].items():assert sha(name)==digest,name
    review=json.loads((P/'review/EXECUTION_GATE.json').read_text())
    assert review['decision']=='PASS_EXECUTE_ONCE'
    assert review['freeze_sha256']==sha(P/'FREEZE.json')
    out=P/'run_01';out.mkdir(exist_ok=False)
    rows=json.loads((P/'SELECTION.json').read_text())['selected']
    slots=[(r['case_id'],s) for r in rows for s in ['parseval','polygon']]
    env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','PYTHONHASHSEED':'0','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1'}
    started=time.monotonic();records=[];denied_systems=set();guard=OwnedCase(1200,interval=.05)
    lock_path=ROOT/'calibergraph_launch_protocol_v2_20261012_05/runtime/owned.lock'
    with lock_path.open('r') as lock:
        fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        with (P/'ATTEMPT_STARTED.json').open('x') as f:json.dump({'freeze_sha256':sha(P/'FREEZE.json'),'slots':66,'no_retries':True,'started_monotonic':started},f);f.flush();os.fsync(f.fileno())
        try:
            with guard:
                for cid,system in slots:
                    if system in denied_systems:
                        records.append({'case_id':cid,'system':system,'status':'NOT_RUN_PERMISSION_PATH_STOP'})
                        continue
                    guard.checkpoint();t=time.monotonic();d=out/(cid+'__'+system);d.mkdir();parent,child=socket.socketpair(socket.AF_UNIX,socket.SOCK_DGRAM)
                    before=len(guard.handles);launches=[];worker=None;stop=None
                    try:
                        with (d/'stdout.txt').open('wb') as stdout,(d/'stderr.txt').open('wb') as stderr:
                            worker=guard.spawn([PY,'-S','-B',str(P/'worker.py'),system,cid,str(child.fileno()),str(d)],pass_fds=(child.fileno(),),stdout=stdout,stderr=stderr,env=env)
                        child.close()
                        while worker.poll() is None:
                            guard.checkpoint()
                            if time.monotonic()-t>=10:stop='CONTROLLER_10S_DEADLINE';guard.cleanup();break
                            ready,_,_=select.select([parent],[],[],.01)
                            if not ready:continue
                            try:message=parent.recv(4096)
                            except ConnectionResetError:break
                            if not message:break
                            request=json.loads(message)
                            if request!={'op':'spawn_z3','argv':['z3','--in','-T:3']}:
                                parent.send(json.dumps({'ok':False,'error':'nonfrozen request'}).encode());continue
                            args=[str(PILOT/'native_local/z3'),'--in','-T:3','-memory:512']
                            with (d/f'z3_{len(launches)}_stderr.txt').open('wb') as err:
                                z=guard.spawn(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,env=env)
                            launches.append({'pid_logging_only':z.pid,'argv':args});fds=array.array('i',[z.stdin.fileno(),z.stdout.fileno()]);parent.sendmsg([json.dumps({'ok':True}).encode()],[(socket.SOL_SOCKET,socket.SCM_RIGHTS,fds)])
                    except PermissionError as e:stop='PERMISSION_DENIED';dump(d/'PERMISSION.json',{'error':repr(e),'no_retry':True})
                    finally:
                        parent.close();child.close();guard.cleanup()
                    result_path=d/'RESULT.json';r=json.loads(result_path.read_text()) if result_path.exists() else {'status':'NO_WORKER_RESULT'}
                    stderr='\n'.join(x.read_text(errors='replace') for x in d.glob('*stderr.txt'))
                    status=stop or r['status']
                    if 'out of memory' in stderr.lower():status='Z3_INTERNAL_MEMORY_LIMIT'
                    row={'case_id':cid,'system':system,'status':status,'worker_status':r.get('status'),'wall_s_including_cleanup':time.monotonic()-t,'worker_returncode':None if worker is None else worker.returncode,'native_launches':launches,'all_reaped':all(x.returncode is not None for x in guard.handles[before:]),'result_path':str(result_path.relative_to(P))}
                    records.append(row);dump(d/'CONTROLLER.json',row)
                    dump(out/'BATCH_PROGRESS.json',{'records':records,'elapsed_s':time.monotonic()-started})
                    print(json.dumps({'done':len(records),'case':cid,'system':system,'status':status,'wall_s':round(row['wall_s_including_cleanup'],3)}),flush=True)
                    if guard.cleanup_errors or any(x.returncode is None for x in guard.handles):
                        raise RuntimeError('STOP_CLEANUP_UNCERTAIN: '+repr(guard.cleanup_errors))
                    if stop=='PERMISSION_DENIED' or r.get('status')=='PERMISSION_DENIED_PATH':
                        denied_systems.add(system)
        except BaseException as e:records.append({'status':'BATCH_STOP','error':repr(e)})
        finally:
            done={(r.get('case_id'),r.get('system')) for r in records}
            for cid,s in slots:
                if (cid,s) not in done:records.append({'case_id':cid,'system':s,'status':'NOT_RUN_BATCH_STOP'})
            dump(out/'BATCH_RESULT.json',{'records':records,'elapsed_s':time.monotonic()-started,'guard':guard.receipt(),'resource_contract':'single worker; per engine/case 10s inclusive work, small cleanup tail disclosed; per Z3 3s and internal512MiB; no aggregate RSS hard limit','new_natural_attempts':len([r for r in records if r.get('result_path')])})
if __name__=='__main__':main()
