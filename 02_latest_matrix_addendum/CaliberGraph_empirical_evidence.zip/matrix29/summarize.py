"""Descriptive extraction only: never invokes an engine or changes raw results."""
import collections,csv,json,statistics
from pathlib import Path
P=Path(__file__).resolve().parent
selection={r['case_id']:r for r in json.loads((P/'SELECTION.json').read_text())['selected']}
batch=json.loads((P/'run_01/BATCH_RESULT.json').read_text())
rows=[]
for controller in batch['records']:
    if 'case_id' not in controller:continue
    cid=controller['case_id'];src=selection[cid]
    path=P/controller['result_path'] if 'result_path' in controller else None
    r=json.loads(path.read_text()) if path and path.exists() else {}
    cs=r.get('candidates',[]);saved=[c for c in cs if c.get('database_file')]
    checks=[c.get('independent_original_SQLite_replay',{}) for c in saved]
    row={'case_id':cid,'schema':src['dbid'],'lexical_stratum':src['stratum'],'system':controller['system'],'status':controller['status'],'worker_status':controller.get('worker_status'),
         'valid_original_input':r.get('admission',{}).get('valid_input'),'phase':r.get('phase'),'native_verdict':r.get('native_verdict'),'native_reason':r.get('native_reason'),
         'solver_calls_started':len(r.get('solver_calls',[])),'solver_calls_completed':sum(c['status']!='STARTED' for c in r.get('solver_calls',[])),
         'candidate_load_attempts':len(cs),'saved_candidates':len(saved),'full_C_valid_candidates':sum(bool(c.get('full_C_valid')) for c in checks),
         'full_C_valid_distinguishing_candidates':sum(bool(c.get('full_C_valid') and c.get('different')) for c in checks),
         'full_C_invalid_candidates':sum(not c.get('full_C_valid',False) for c in checks),
         'asymmetric_query_error_candidates':sum(bool(c.get('full_C_valid') and c.get('asymmetric_query_error')) for c in checks),
         'wall_s':controller.get('wall_s_including_cleanup'),'own_peak_rss_bytes':r.get('own_peak_rss_bytes'),'own_cpu_s':r.get('own_cpu_s'),
         'all_reaped':controller.get('all_reaped'),'error':r.get('error'),'query_gate_reasons':r.get('query_gate_reasons'),
         'solver_call_statuses':dict(collections.Counter(c['status'] for c in r.get('solver_calls',[]))),
         'result_path':controller.get('result_path')}
    rows.append(row)
(P/'MATRIX.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
with (P/'MATRIX.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
guard_summary={k:v for k,v in batch['guard'].items() if k not in ('events','returncodes')}
guard_summary['returncode_counts']=dict(collections.Counter(batch['guard']['returncodes']))
summary={'development_only':True,'pairs':len(selection),'slots':len(rows),'batch_elapsed_s':batch['elapsed_s'],'guard':guard_summary,'systems':{}}
for system in ['parseval','polygon']:
    rr=[r for r in rows if r['system']==system]
    summary['systems'][system]={'all_pairs_denominator':len(rr),'statuses':dict(collections.Counter(r['status'] for r in rr)),
      'by_schema':{db:dict(collections.Counter(r['status'] for r in rr if r['schema']==db)) for db in sorted({r['schema'] for r in rr})},
      'by_lexical_stratum':{s:dict(collections.Counter(r['status'] for r in rr if r['lexical_stratum']==s)) for s in ['VALUE','AGG_BAG','OTHER']}}
    for field in ['solver_calls_started','solver_calls_completed','candidate_load_attempts','saved_candidates','full_C_valid_candidates','full_C_valid_distinguishing_candidates','full_C_invalid_candidates','asymmetric_query_error_candidates']:
        summary['systems'][system][field]=sum(r[field] for r in rr)
    costs=[r['wall_s'] for r in rr if r['wall_s'] is not None]
    summary['systems'][system]['descriptive_wall_seconds']={'sum':sum(costs),'median':statistics.median(costs),'max':max(costs)}
    summary['systems'][system]['own_peak_rss_bytes_max']=max((r['own_peak_rss_bytes'] or 0) for r in rr)
    summary['systems'][system]['pairs_with_any_valid_distinguishing_saved_candidate']=sum(r['full_C_valid_distinguishing_candidates']>0 for r in rr)
summary['no_performance_winner_comparison']='Unequal row bounds and semantic support; no independently certified common domain.'
(P/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='guard'},ensure_ascii=False,indent=2))
