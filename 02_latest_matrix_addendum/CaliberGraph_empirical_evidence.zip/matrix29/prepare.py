"""Pre-outcome deterministic schema/lexical-stratum development inventory."""
from pathlib import Path
import collections,hashlib,json,re,datetime
P=Path(__file__).resolve().parent;ROOT=P.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(name,x):
    with (P/name).open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
source=ROOT/'calibergraph_distinct_evidence_20261012_03/sources_local'
protocol={'role':'DEVELOPMENT_AUDIT_ONLY_PRIOR_CORPUS_STATIC_EXPOSURE','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'population':1534,'schemas':11,'max_pairs':33,'selection':'For each sorted dbid: first SHA256-ranked pair per nonempty lexical stratum VALUE, AGG_BAG, OTHER, then fill to three by overall rank. No outcome, support or old-case exclusion. No replacement.',
 'rank':'sha256(cg-empirical29-v1|dbid|index)','lexical_strata':{'VALUE':'CAST, STRFTIME, DATE, DATETIME, SUBSTR, SUBSTRING, ROUND, IIF, CASE, COALESCE, NULLIF function/keyword token in either SQL (outside strings/comments)','AGG_BAG':'otherwise COUNT,SUM,AVG,MIN,MAX,DISTINCT,GROUP BY,UNION token','OTHER':'otherwise'},
 'systems':['parseval_pinned_resource_adapted','polygon_pilot13_UA_resource_adapted'],
 'versions':'No patched COUNT P1/P2/P3 and no new semantic adapter; raw code and resource overlays separately fingerprinted.',
 'resources':{'single_worker':True,'per_solver_call_seconds':3,'per_case_system_end_to_end_seconds':10,'whole_batch_natural_seconds':1200,'z3_internal_memory_MiB':512,'aggregate_RSS_hard_limit':False,'python_own_RSS_soft_stop_bytes':1073741824,'no_retry':True,'OMP_threads':1},
 'admission':'Original DDL+EXPLAIN validity for all. ParSEval native lower/generate reports support; every candidate independently checked against original SQLite full DDL. Polygon only existing exact source-DDL-hash mappings (superhero/toxicology), conservative query-semantic gate and existing UA encoder; no full-schema type coercion or new per-case classes.',
 'replay':'Read saved emitted databases only; original unchanged SQL/DDL, foreign_keys=ON,deferred insert,integrity_check and foreign_key_check; all source tables/columns required; no witness repair. SQLite bag comparison unless BOTH queries order. Asymmetric execution error recorded separately from differing successful rows.',
 'primary_outputs':['per-system full33 disposition','per-schema and lexical-stratum disposition','full-C-valid concrete distinguishing witness yield / all33','invalid or non-distinguishing emitted witnesses','unsupported and failures without denominator deletion'],
 'fairness':'Equal time caps are not equal search domains. ParSEval expands candidate row counts; Polygon N<=1. No speed winner or solve-rate comparison unless independently established common query/type/C/row/comparison domains; otherwise report descriptive costs only.',
 'interpretation':'ParSEval EQ means sampled agreement, Polygon EQU means bounded symbolic UNSAT over encoded typed fragment, neither universal correctness. Tools share Z3 and borrowed code/concepts may exist; no independent-implementation or two-oracle claim.',
 'hypothesis':'Determine whether these existing paths show repeatable cross-schema reliability/coverage patterns under unchanged SQLite semantics; no required bug or method win.',
 'stop':'Stop at batch deadline, cleanup uncertainty or new permission denial. Record blocked path and continue independent path if safely possible. No attempt to broaden coverage or tune after outcomes.',
 'sources':{str((source/n).relative_to(ROOT)):sha(source/n) for n in ['disprove-bird.jsonl','schema.json']}}
dump('PROTOCOL.json',protocol)
schemas=json.loads((source/'schema.json').read_text());rows=[json.loads(x) for x in (source/'disprove-bird.jsonl').read_text().splitlines()]
assert len(rows)==1534 and len(schemas)==11
def clean(q):return re.sub(r"'([^']|'')*'|--[^\n]*|/\*.*?\*/",' ',q,flags=re.S)
def category(q):
    q=clean(q)
    if re.search(r'\b(CAST|STRFTIME|DATE|DATETIME|SUBSTR|SUBSTRING|ROUND|IIF|CASE|COALESCE|NULLIF)\b',q,re.I):return 'VALUE'
    if re.search(r'\b(COUNT|SUM|AVG|MIN|MAX|DISTINCT|GROUP\s+BY|UNION)\b',q,re.I):return 'AGG_BAG'
    return 'OTHER'
inventory=[];by={}
for lineno,r in enumerate(rows,1):
    cid=r['dbid']+'__'+str(r['index']);rank=hashlib.sha256(('cg-empirical29-v1|'+r['dbid']+'|'+str(r['index'])).encode()).hexdigest()
    entry={'case_id':cid,'dbid':r['dbid'],'index':str(r['index']),'source_line':lineno,'stratum':category(r['gold']+'\n'+r['predicted']),'rank':rank,'selected':False}
    inventory.append(entry);by[cid]=r
selected=[]
for dbid in sorted(schemas):
    pool=sorted([x for x in inventory if x['dbid']==dbid],key=lambda x:x['rank']);chosen=[]
    for cat in ['VALUE','AGG_BAG','OTHER']:
        got=next((x for x in pool if x['stratum']==cat),None)
        if got:chosen.append(got)
    for x in pool:
        if len(chosen)==3:break
        if x not in chosen:chosen.append(x)
    selected.extend(chosen)
(P/'inputs').mkdir()
for e in selected:
    e['selected']=True;r=by[e['case_id']];d=P/'inputs'/e['case_id'];d.mkdir()
    for name,value in [('gold.sql',r['gold']),('predicted.sql',r['predicted']),('full-schema.sql',';\n'.join(schemas[e['dbid']]))]: (d/name).write_text(value)
    e['input_hashes']={x.name:sha(x) for x in d.iterdir()};e['development_only']=True
    e['source_record_hash']=hashlib.sha256(json.dumps(r,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
dump('SELECTION.json',{'all_records':inventory,'selected':selected,'outcome_fields_not_used_or_exported':True,'per_schema':dict(collections.Counter(x['dbid'] for x in selected))})
print(json.dumps({'selected':len(selected),'schemas':len(set(x['dbid'] for x in selected)),'strata':dict(collections.Counter(x['stratum'] for x in selected)),'ids':[x['case_id'] for x in selected]}))
