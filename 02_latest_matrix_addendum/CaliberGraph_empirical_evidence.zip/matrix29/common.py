from pathlib import Path
import collections,hashlib,json,sqlite3,time
P=Path(__file__).resolve().parent;ROOT=P.parent
PILOT=ROOT/'calibergraph_polygon_pilot_20261012_13'
PARSEVAL=ROOT/'calibergraph_parseval_admission_20261011_03'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def quote(s):return '"'+s.replace('"','""')+'"'
def dump(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=repr)+'\n')
def inputs(cid):
    d=P/'inputs'/cid
    return d,(d/'full-schema.sql').read_text(),[(d/(x+'.sql')).read_text() for x in ['gold','predicted']]
def fresh(ddl,seconds=2):
    db=sqlite3.connect(':memory:');end=time.monotonic()+seconds
    db.set_progress_handler(lambda:int(time.monotonic()>end),1000)
    db.execute('PRAGMA foreign_keys=ON');db.executescript(ddl)
    return db
def metadata(db):
    result=[]
    for (n,) in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"):
        result.append({'table':n,'columns':[dict(zip(['cid','name','type','notnull','default','pk'],r)) for r in db.execute('PRAGMA table_info('+quote(n)+')')],
                       'foreign_keys':list(db.execute('PRAGMA foreign_key_list('+quote(n)+')')),'indexes':list(db.execute('PRAGMA index_list('+quote(n)+')'))})
    return result
def replay(cid,data,ordered=False):
    _,ddl,queries=inputs(cid);db=fresh(ddl);r={'full_C_valid':False,'different':False,'query_errors':[]}
    try:
        specs=metadata(db);actual={x['table'].casefold():x['table'] for x in specs}
        if len(data)!=len(actual) or {n.casefold() for n in data}!=set(actual):raise ValueError('full source table coverage mismatch')
        db.execute('BEGIN');db.execute('PRAGMA defer_foreign_keys=ON')
        counts={}
        for n,tab in data.items():
            name=actual[n.casefold()];columns=tab['columns'];rows=tab['rows'];spec=next(t for t in specs if t['table']==name)
            expected={c['name'].casefold():c['name'] for c in spec['columns']}
            if len(columns)!=len(expected) or {c.casefold() for c in columns}!=set(expected):raise ValueError('full source column coverage mismatch')
            columns=[expected[c.casefold()] for c in columns];counts[name]=len(rows)
            for row in rows:
                if len(row)!=len(columns) or any(type(x) not in (int,float,str,type(None),bool) for x in row):raise ValueError('unsupported serialized value or row shape')
                db.execute('INSERT INTO '+quote(name)+' ('+','.join(map(quote,columns))+') VALUES ('+','.join('?' for _ in row)+')',row)
        r['foreign_key_check']=db.execute('PRAGMA foreign_key_check').fetchall()
        r['integrity_check']=db.execute('PRAGMA integrity_check').fetchall()
        if r['foreign_key_check'] or r['integrity_check']!=[('ok',)]:raise ValueError('full source constraint violation')
        db.commit();r['full_C_valid']=True;r['rows_per_table']=counts
        r['outputs']=[]
        db.execute('PRAGMA query_only=ON')
        for q in queries:
            try:r['outputs'].append(db.execute(q).fetchall());r['query_errors'].append(None)
            except sqlite3.Error as e:r['outputs'].append(None);r['query_errors'].append(str(e))
        if not any(r['query_errors']):r['different']=r['outputs'][0]!=r['outputs'][1] if ordered else collections.Counter(r['outputs'][0])!=collections.Counter(r['outputs'][1])
        r['asymmetric_query_error']=bool(r['query_errors'][0])!=bool(r['query_errors'][1]);r['ordered']=ordered
    except Exception as e:r['validation_error']=type(e).__name__+': '+str(e)
    finally:db.close()
    return r
def admission(cid):
    d,ddl,queries=inputs(cid);db=fresh(ddl);r={'case_id':cid,'source_ddl_hash':sha(d/'full-schema.sql'),'sqlite_version':sqlite3.sqlite_version,'queries':[]}
    try:
        r['full_C_inventory']=metadata(db)
        db.execute('PRAGMA query_only=ON')
        for q in queries:
            try:db.execute('EXPLAIN '+q).fetchall();r['queries'].append({'valid':True})
            except sqlite3.Error as e:r['queries'].append({'valid':False,'error':str(e)})
    finally:db.close()
    r['valid_input']=all(x['valid'] for x in r['queries']);r['polygon_mapping']=None
    for old in ['superhero__750','toxicology__319']:
        inv=json.loads((PILOT/'inputs_local'/f'{old}.json').read_text())
        if inv['source_ddl_sha256']==r['source_ddl_hash']:r['polygon_mapping']=str(PILOT/'inputs_local'/f'{old}.json')
    r['polygon_schema_gate']='EXACT_PREVIOUSLY_REPLAYED_SCHEMA_MAPPING' if r['polygon_mapping'] else 'UNSUPPORTED_EXISTING_FULL_SCHEMA_MAPPING'
    return r
