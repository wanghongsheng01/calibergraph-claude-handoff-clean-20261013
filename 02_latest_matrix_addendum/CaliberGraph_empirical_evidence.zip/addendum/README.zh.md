# 明早验收：第29轮独立实证附页

本轮整理已完成；总体投稿任务仍HOLD。此目录是新增交付，不覆盖第24轮候选稿、第29轮冻结证据或P19。

- CaliberGraph_empirical_addendum.pdf：三页英文附页；第1页为完整分母与执行事实，第2页为稿件修订索引及证据绑定，第3页为一页最终科学判断。
- FINAL_SCIENTIFIC_JUDGMENT.zh.md：中文科学判断。还缺可迁移、可证伪的系统性发现；不要求所有baseline都输。
- CaliberGraph_33pair_matrix.csv：与第29轮MATRIX.csv逐字节一致，全部66槽。
- PROPOSED_AMENDMENTS.json / .zh.md：11处精确原文、替换建议、源行号及哈希，均未应用。
- SOURCE_BINDING.json：已交付候选稿与第29轮证据的绑定。
- review/：本附页独立内容审核；第29轮的预执行签字、116候选独立回放及最终审核随证据ZIP原样保留。
- surface/：三页渲染、字体与日志检查。自动bbox间距审计因pdftotext崩溃不可用，未冒称通过；逐页目视检查完成，最终日志无越界、缺字或未定义引用，字体均嵌入。

ZIP含第29轮完整审计文件、原候选稿只读源快照及本附页材料；依赖二进制仅提供原冻结指纹，不随包分发。所有结果仍是开发审计，18与1不可排名，样本不跨轮合并。本轮未新增SQL执行、solver调用、bug搜索或方法扩展。未push、未投稿、未把沉默视为批准。

Library为单独私有新文件，不替换旧候选稿。准确Library IDs与上传结果在本地LIBRARY_UPLOAD_RECEIPTS.json及最终回复记录；它们在ZIP上传之后产生，故不虚构为已包含在该ZIP中。
