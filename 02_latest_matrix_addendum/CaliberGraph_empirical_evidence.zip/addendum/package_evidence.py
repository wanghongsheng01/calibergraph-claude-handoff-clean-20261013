import hashlib,json,zipfile
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parent;M=R/'calibergraph_empirical_matrix_20261012_29'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binding=json.loads((P/'SOURCE_BINDING.json').read_text())
assert all(sha(R/n)==h for n,h in binding['files'].items())
old=json.loads((M/'DELIVERY_MANIFEST.json').read_text())
assert all(sha(M/n)==h for n,h in old['files'].items())
assert (P/'CaliberGraph_33pair_matrix.csv').read_bytes()==(M/'MATRIX.csv').read_bytes()
files={}
for f in M.rglob('*'):
 if f.is_file() and '__pycache__' not in f.parts:files['matrix29/'+str(f.relative_to(M))]=f
for f in P.rglob('*'):
 rel=f.relative_to(P)
 if not f.is_file() or rel.parts[0] in ['private_helpers','build'] or f.name in ['CaliberGraph_empirical_evidence.zip','EVIDENCE_MANIFEST.json','PACKAGE_RECEIPT.json','LIBRARY_UPLOAD_RECEIPTS.json','upload_request.json','upload_result.private.json']:continue
 files['addendum/'+str(rel)]=f
for name in binding['files']:
 f=R/name
 if f.suffix in ['.tex','.bib']:files['candidate_source_snapshot/'+str(f.relative_to(R/'calibergraph_candidate_dke_20261012_24'))]=f
manifest={'privacy':'private author review; no sharing action','new_SQL_executions':0,'new_solver_calls':0,'push':False,'submission_task_complete':False,'scientific_judgment':'HOLD','files':{n:{'sha256':sha(f),'bytes':f.stat().st_size} for n,f in sorted(files.items())}}
(P/'EVIDENCE_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
files['EVIDENCE_MANIFEST.json']=P/'EVIDENCE_MANIFEST.json'
z=P/'CaliberGraph_empirical_evidence.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
 for n,f in sorted(files.items()):out.write(f,n)
with zipfile.ZipFile(z) as out:
 assert out.testzip() is None
 for n,r in manifest['files'].items():assert hashlib.sha256(out.read(n)).hexdigest()==r['sha256']
receipt={'archive':z.name,'bytes':z.stat().st_size,'sha256':sha(z),'members':len(files),'CRC':'PASS','member_sha256':'ALL_PASS','old_candidate_8_files_unchanged':True,'matrix29_520_delivered_files_unchanged':True,'CSV_byte_identical':True}
(P/'PACKAGE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
request={'uploads':[{'local_path':str(P/n),'purpose':'create_library_file','library_artifact_type':typ} for n,typ in [('CaliberGraph_empirical_addendum.pdf','report'),('CaliberGraph_33pair_matrix.csv','sheet'),('CaliberGraph_empirical_evidence.zip','other')]]}
(P/'upload_request.json').write_text(json.dumps(request)+'\n')
